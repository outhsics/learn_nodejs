// lo  localhost 0.0.1 
// ls ll yum remove net-tools
// ll -a 隐藏文件
// 吃的
// cd  
// ll   文件夹下文件列表
// ls - l 
// ls - a  显示全部文件
// pwd 当前路径  __driname   当前进程的路径process.cwd

// mkdir  make directory
   
// rm -rf -r    recursion （递归） force（强制）
// rm -r -f   严重注意规范
// touch 
// vi i  进入编辑
        // esc 退出编辑
        // dd 在推出编辑下，删除当前光标所在行
        // wq 保存并推出
        // q！ 不保存当前修改并推出
// cp
// mv
// user group user root others
// useradd password 